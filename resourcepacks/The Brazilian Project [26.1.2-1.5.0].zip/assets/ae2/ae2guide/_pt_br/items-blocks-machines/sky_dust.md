---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pó de Pedra do Céu
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# Pó de Pedra do Céu

<ItemImage id="sky_dust" scale="4" />

Um bloco de <ItemLink id="sky_stone_block" /> que foi triturado por um <ItemLink id="inscriber" />. Usado na produção de
<ItemLink id="cell_component_256k" /> e <ItemLink id="sky_stone_block" />.

Também pode ser obtido apontando um <ItemLink id="annihilation_plane" /> para cima na altura máxima de construção do mundo.

## Receita

<RecipeFor id="sky_dust" />

---
navigation:
  parent: turbine/turbine-index.md
  title: Porta de Redstone da Turbina
  icon: turbine_redstone_port
  position: 37
item_ids:
  - colossal_reactors:turbine_redstone_port
categories:
  - Portas
---

# Porta de Redstone da Turbina

<BlockImage id="turbine_redstone_port" scale="4" />

A **Porta de Redstone da Turbina** liga o estado da turbina à **redstone** (por exemplo saída de comparador ou reagir a um sinal de redstone — depende do modo que você escolher).

## Recursos

- **Clique com o botão direito** para escolher como o estado da turbina afeta a redstone. Dicas de ferramenta em cada botão explicam o modo.

- Use-a para **parar ou pausar** a turbina por fora sem quebrar o multibloco — mesma ideia da [Porta de Redstone do Reator](../multiblock/redstone_port.md).

- Coloque-a de forma que pó, comparadores ou máquinas no lado de **fora** da carcaça possam alcançá-la.

---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Pó de Entro
    icon: extendedae:entro_dust
categories:
- entro system
item_ids:
- extendedae:entro_dust
---

# Pó de Entro

<Row>
<ItemImage id="extendedae:entro_dust" scale="4"></ItemImage>
</Row>

Você pode obtê-lo triturando um <ItemLink id="extendedae:entro_crystal" /> ou quebrando [Fluix Entroizado Brotante](./entro_budding.md).

Ele é usado para fabricar certas máquinas do ExtendedAE e o <ItemLink id="extendedae:entro_ingot" />.
